<?php
/**
 * Plugin Name: NC Ariane
 * Plugin URI: https://www.net-com.fr/
 * Description: Génère un fil d'ariane personnalisé pour chaque type de contenu
 * Version: 0.1
 * Author: Net.Com
 */

require_once "classes/NC_Ariane.php";
