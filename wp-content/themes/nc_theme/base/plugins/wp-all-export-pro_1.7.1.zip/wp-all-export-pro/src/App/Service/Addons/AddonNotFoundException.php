<?php

namespace Wpae\App\Service\Addons;


class AddonNotFoundException extends \Exception
{

}


